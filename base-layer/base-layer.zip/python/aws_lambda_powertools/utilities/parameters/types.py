from typing_extensions import Literal

TransformOptions = Literal["json", "binary", "auto", None]
